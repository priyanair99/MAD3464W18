
package multithreading;


public class MyText implements Runnable{

    @Override
    public void run() {
        System.out.println("Texting..");
    }
    
}
