
package multithreading;


public class MyMessage extends Thread{
    public void run(){
        System.out.println("Messaging...");
    }
}


